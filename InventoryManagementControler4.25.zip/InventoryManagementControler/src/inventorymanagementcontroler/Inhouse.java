/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inventorymanagementcontroler;

/**
 *
 * @author jonathankoerber
 */
public class Inhouse extends Part {
    int machineID;
    Inhouse(String name, int partId, double price, int instock, int min, int max, int machineID){
        super(name, partId, price, instock, min, max);
        this.setMachineId(machineID);
    }
    public void setMachineId(int machine){
        this.machineID = machine;
    }
    public int getMachineId(){
        return this.machineID;
}
}
